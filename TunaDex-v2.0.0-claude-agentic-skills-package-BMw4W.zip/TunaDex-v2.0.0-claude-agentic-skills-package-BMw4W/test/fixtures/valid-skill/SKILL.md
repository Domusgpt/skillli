---
name: test-skill
version: 1.0.0
description: A test skill for validating the skillli parser works correctly
author: testuser
license: MIT
tags: [testing, validation]
category: development
trust-level: community
user-invocable: true
---

# Test Skill

This is a test skill used for unit testing the skillli parser.

## Usage

Invoke this skill when you need to test something.
