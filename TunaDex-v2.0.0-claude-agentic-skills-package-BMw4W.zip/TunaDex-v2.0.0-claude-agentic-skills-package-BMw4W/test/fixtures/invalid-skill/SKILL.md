---
name: INVALID_NAME!!
version: not-semver
description: short
---

Missing required fields and invalid values.
